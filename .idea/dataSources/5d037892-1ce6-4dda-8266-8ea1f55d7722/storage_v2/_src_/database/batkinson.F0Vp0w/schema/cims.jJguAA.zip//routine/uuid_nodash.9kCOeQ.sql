create function uuid_nodash()
  returns character varying
language plpgsql
as $$
declare
  uuid text = uuid_generate_v4();
begin
  return replace(uuid, '-', '');
end
$$;

