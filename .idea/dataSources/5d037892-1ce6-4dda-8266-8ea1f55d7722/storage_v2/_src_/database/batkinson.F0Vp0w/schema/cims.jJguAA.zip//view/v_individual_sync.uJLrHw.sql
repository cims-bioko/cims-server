create view v_individual_sync as
  SELECT individual.uuid,
         to_char((individual.dob) :: timestamp with time zone, 'YYYY-MM-DD' :: text) AS dob,
         individual.extid,
         individual.first_name                                                       AS firstname,
         individual.gender,
         individual.last_name                                                        AS lastname,
         individual.home                                                             AS currentresidence,
         individual.home_role                                                        AS relationshiptohead,
         individual.middle_name                                                      AS othernames,
         individual.phone1                                                           AS phonenumber,
         individual.phone2                                                           AS otherphonenumber,
         individual.contact_name                                                     AS pointofcontactname,
         individual.contact_phone                                                    AS pointofcontactphonenumber,
         individual.language                                                         AS languagepreference,
         individual.status,
         individual.nationality,
         individual.dip                                                              AS otherid,
         (individual.attrs) :: text                                                  AS attrs
  FROM individual
  WHERE ((individual.deleted IS NULL) AND ((individual.extid) :: text <> 'UNK' :: text) AND
         (individual.home IS NOT NULL));

comment on view v_individual_sync
is 'used to generate mobile individuals table';

