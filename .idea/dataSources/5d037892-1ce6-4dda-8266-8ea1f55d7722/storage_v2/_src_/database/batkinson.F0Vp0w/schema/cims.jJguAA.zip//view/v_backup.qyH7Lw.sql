create view v_backup as
  SELECT b.schema_name, d.description, b.created
  FROM ((backup b
      JOIN pg_namespace ns ON ((b.schema_name = (ns.nspname) :: text)))
      JOIN pg_description d ON ((ns.oid = d.objoid)));

