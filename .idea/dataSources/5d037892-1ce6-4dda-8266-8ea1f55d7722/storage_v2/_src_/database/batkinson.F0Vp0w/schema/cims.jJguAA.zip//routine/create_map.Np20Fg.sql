create function create_map(locality_uuid character varying, map_name character varying)
  returns character varying
language plpgsql
as $$
declare
  locality locationhierarchy%rowtype;
  map_level_uuid locationhierarchylevel.uuid%type;
  map_uuid locationhierarchy.uuid%type;
  map_extid locationhierarchy.extid%type;
  existing_map locationhierarchy%rowtype;
begin

  if not map_name ~ '^M\d{4}$' then
    raise exception '% is not a valid map name, must match M####', map_name;
  end if;

  -- find and store the one-and-only identified locality
  select * into strict locality from locationhierarchy lh join locationhierarchylevel lhl on lh.level = lhl.uuid where lhl.name = 'Locality' and lh.uuid = locality_uuid;
  raise notice 'found locality: %, %', locality.uuid, locality.name;

  if locality.name ~ '^Sin ' then
    raise exception 'creating map in % is not allowed', locality.name;
  end if;

  -- store the level uuid for maps
  select uuid into strict map_level_uuid from locationhierarchylevel where name = 'MapArea';
  raise notice 'found map level %', map_level_uuid;

  -- construct the map extid based on specified map name and locality
  map_extid := concat(map_name, '/', locality.name);

  -- return the existing map if it exists, otherwise create it
  begin
    select * into strict existing_map from locationhierarchy lh join locationhierarchylevel lhl on lh.level = lhl.uuid where lhl.name = 'MapArea' and lh.extid = map_extid;
    raise notice 'found existing map for extid %, %', map_extid, existing_map.uuid;
    return existing_map.uuid;
    exception
      when NO_DATA_FOUND then
        raise notice 'existing map with extid % not found, creating', map_extid;
        -- generate a new map uuid
        select uuid_nodash() into strict map_uuid;
        raise notice 'new map uuid: %', map_uuid;
        -- insert the new map
        insert into locationhierarchy values (map_uuid, concat(map_name, '/', locality.name), map_name, map_level_uuid, locality.uuid);
        return map_uuid;
      when TOO_MANY_ROWS then
        raise exception 'multiple maps with extid %', map_extid;
  end;

end
$$;

