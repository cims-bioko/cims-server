create view v_location_sync as
  SELECT l.uuid,
         l.extid,
         l.hierarchy                                AS hierarchyuuid,
         COALESCE(l.name, '' :: character varying)  AS name,
         l.description,
         lm.name                                    AS mapareaname,
         ls.name                                    AS sectorname,
         (to_uniquebid((l.extid) :: text)).building AS buildingnumber,
         (st_y(l.global_pos)) :: character varying  AS latitude,
         (st_x(l.global_pos)) :: character varying  AS longitude,
         (l.attrs) :: text                          AS attrs
  FROM (((location l
      JOIN locationhierarchy ls ON (((l.hierarchy) :: text = (ls.uuid) :: text)))
      JOIN locationhierarchy lm ON (((ls.parent) :: text = (lm.uuid) :: text)))
      JOIN locationhierarchy ll ON (((lm.parent) :: text = (ll.uuid) :: text)))
  WHERE (l.deleted IS NULL);

comment on view v_location_sync
is 'used to generate mobile locations table';

