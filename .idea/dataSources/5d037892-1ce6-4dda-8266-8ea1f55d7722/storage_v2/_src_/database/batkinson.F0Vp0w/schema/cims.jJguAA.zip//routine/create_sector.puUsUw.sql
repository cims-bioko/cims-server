create function create_sector(map_uuid character varying, sector_name character varying)
  returns character varying
language plpgsql
as $$
declare
  map locationhierarchy%rowtype;
  locality locationhierarchy%rowtype;
  sector_level_uuid locationhierarchylevel.uuid%type;
  sector_uuid locationhierarchy.uuid%type;
  sector_extid locationhierarchy.extid%type;
  existing_sector locationhierarchy%rowtype;
begin

  if not sector_name ~ '^S\d{3}$' then
    raise exception '% is not a valid sector name, must match S###', sector_name;
  end if;

  -- find and store the one-and-only identified map
  select * into strict map from locationhierarchy lh join locationhierarchylevel lhl on lh.level = lhl.uuid where lhl.name = 'MapArea' and lh.uuid = map_uuid;
  raise notice 'found map: %, %', map.uuid, map.name;

  -- find and store the one-and-only locality (the parent of the map)
  select * into strict locality from locationhierarchy lh join locationhierarchylevel lhl on lh.level = lhl.uuid where lhl.name = 'Locality' and lh.uuid = map.parent;
  raise notice 'found locality: %, %', locality.uuid, locality.name;

  if locality.name ~ '^Sin ' or map.name ~ '^Sin ' then
    raise exception 'creating sector in %, % is not allowed', locality.name, map.name;
  end if;

  -- store the level uuid for sectors
  select uuid into strict sector_level_uuid from locationhierarchylevel where name = 'Sector';
  raise notice 'found sector level %', sector_level_uuid;

  -- construct the sector extid based on specified sector name, map and locality
  sector_extid := concat(map.name, sector_name, '/', locality.name);

  -- return the existing sector if it exists, otherwise create it
  begin
    select * into strict existing_sector from locationhierarchy lh join locationhierarchylevel lhl on lh.level = lhl.uuid where lhl.name = 'Sector' and lh.extid = sector_extid;
    raise notice 'found existing sector for extid %, %', sector_extid, existing_sector.uuid;
    return existing_sector.uuid;
    exception
      when NO_DATA_FOUND then
        raise notice 'existing sector with extid % not found, creating', sector_extid;
        -- generate a new sector uuid
        select uuid_nodash() into strict sector_uuid;
        raise notice 'new sector uuid: %', sector_uuid;
        -- insert the new sector
        insert into locationhierarchy values (sector_uuid, sector_extid, sector_name, sector_level_uuid, map.uuid);
        return sector_uuid;
      when TOO_MANY_ROWS then
        raise exception 'multiple sectors with extid %', sector_extid;
  end;

end
$$;

