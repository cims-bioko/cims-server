create view v_fieldworker_sync as
  SELECT fieldworker.uuid,
         fieldworker.extid,
         fieldworker.idprefix,
         fieldworker.first_name    AS firstname,
         fieldworker.last_name     AS lastname,
         fieldworker.password_hash AS password
  FROM fieldworker
  WHERE ((fieldworker.deleted IS NULL) AND ((fieldworker.extid) :: text <> 'UNK' :: text));

comment on view v_fieldworker_sync
is 'used to generate mobile fieldworkers table';

