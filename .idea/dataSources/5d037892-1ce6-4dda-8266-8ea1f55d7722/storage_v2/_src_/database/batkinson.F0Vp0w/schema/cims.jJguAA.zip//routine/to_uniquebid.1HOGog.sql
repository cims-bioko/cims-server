create function to_uniquebid(str text)
  returns uniquebid
language plpgsql
as $$
declare
  parsed text[];
  result uniquebid;
begin
  select regexp_matches(str, '((M(\d{4}))(S(\d{3}))(E(\d{3}))(P(\d{2}))(-d(\d+))?)') into parsed;
  if FOUND then
    result.formatted := parsed[1];
    result.map_name := parsed[2];
    result.map := parsed[3]::integer;
    result.sector_name := parsed[4];
    result.sector := parsed[5]::integer;
    result.building_name := parsed[6];
    result.building := parsed[7]::integer;
    result.floor_name := parsed[8];
    result.floor := parsed[9]::integer;
    result.duplicate_name := parsed[10];
    result.duplicate := parsed[11]::integer;
    return result;
  else
    return null;
  end if;
end
$$;

