create view v_locationhierarchy_sync as
  SELECT lh.uuid, lh.extid, lh.name, l.name AS level, lh.parent, (lh.attrs) :: text AS attrs
  FROM (locationhierarchy lh
      JOIN locationhierarchylevel l ON (((lh.level) :: text = (l.uuid) :: text)));

comment on view v_locationhierarchy_sync
is 'used to generate mobile locationhierachy table';

